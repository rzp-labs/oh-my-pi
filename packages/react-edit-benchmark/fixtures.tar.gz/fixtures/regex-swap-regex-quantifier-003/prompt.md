# Fix the bug in `utils.js`

A regex quantifier was swapped, changing whitespace matching.

Find and fix this issue.