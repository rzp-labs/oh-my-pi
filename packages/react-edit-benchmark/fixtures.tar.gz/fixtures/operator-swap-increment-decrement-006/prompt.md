# Fix the bug in `SuspenseScrubber.js`

An increment/decrement operator points the wrong direction.

The issue is in the `SuspenseScrubber` function.

Replace the increment/decrement operator with the intended one.