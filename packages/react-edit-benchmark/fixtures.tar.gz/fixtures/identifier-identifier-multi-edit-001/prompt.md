# Fix the bug in `Button.js`

An identifier is misspelled in multiple separate locations.

The issue is on line 43.

Restore the identifier to its original spelling in all affected locations.