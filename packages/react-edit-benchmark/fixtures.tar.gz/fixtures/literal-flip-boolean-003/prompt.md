# Fix the bug in `ReactProfilerTimer.js`

A boolean literal is inverted.

Find and fix this issue.