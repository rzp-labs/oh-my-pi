# Fix the bug in `useCanvasInteraction.js`

An arithmetic operator was swapped.

Find and fix this issue.