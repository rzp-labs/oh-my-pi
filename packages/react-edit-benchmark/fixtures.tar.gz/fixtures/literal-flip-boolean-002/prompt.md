# Fix the bug in `ReactFeatureFlags.js`

A boolean literal is inverted.

The issue is in the `references` function.

Flip the boolean literal to the intended value.