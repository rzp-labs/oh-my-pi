# Fix the bug in `isCustomElement.js`

A duplicated line contains a subtle literal/operator change.

The issue is on line 12.

Fix the literal or operator on the duplicated line.