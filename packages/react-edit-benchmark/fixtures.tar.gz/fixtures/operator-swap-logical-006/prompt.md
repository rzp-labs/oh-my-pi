# Fix the bug in `FlamegraphChartBuilder.js`

A boolean operator is incorrect.

The issue is in the `getChartData` function.

Use the intended boolean operator.