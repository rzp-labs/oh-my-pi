# Fix the bug in `ReactNoopFlightClient.js`

An equality operator is inverted.

The issue is on line 86.

Fix the equality comparison operator.