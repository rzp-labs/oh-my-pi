# Fix the bug in `formatConsoleArguments.js`

An arithmetic operator was swapped.

The issue is on line 33.

Correct the arithmetic operator.