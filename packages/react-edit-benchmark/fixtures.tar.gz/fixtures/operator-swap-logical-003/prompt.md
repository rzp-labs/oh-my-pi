# Fix the bug in `DevTools.js`

A boolean operator is incorrect.

Find and fix this issue.