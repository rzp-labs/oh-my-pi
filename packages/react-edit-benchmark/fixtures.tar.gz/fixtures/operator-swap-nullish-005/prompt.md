# Fix the bug in `ReactLogo.js`

A nullish coalescing operator was swapped.

The issue is on line 22.

Use the intended nullish/logical operator.