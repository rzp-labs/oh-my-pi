# Fix the bug in `ReactFlightDOMClientNode.js`

A string literal contains a lookalike unicode dash.

The issue is near the top of the file.

Replace the unicode dash with a plain ASCII hyphen.