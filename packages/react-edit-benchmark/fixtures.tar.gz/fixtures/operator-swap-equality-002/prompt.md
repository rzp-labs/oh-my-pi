# Fix the bug in `ReactFlightUnbundledNodeRegister.js`

An equality operator is inverted.

The issue is in the `register` function.

Fix the equality comparison operator.