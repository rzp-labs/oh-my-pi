# Fix the bug in `ReactFizzConfigMarkup.js`

A duplicated line contains a subtle literal/operator change.

The issue is in the `writeCompletedRoot` function.

Fix the literal or operator on the duplicated line.