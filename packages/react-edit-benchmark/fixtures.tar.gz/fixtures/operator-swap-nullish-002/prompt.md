# Fix the bug in `GeneralSettings.js`

A nullish coalescing operator was swapped.

The issue is in the `GeneralSettings` function.

Use the intended nullish/logical operator.