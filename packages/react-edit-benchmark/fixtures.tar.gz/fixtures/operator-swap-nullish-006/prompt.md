# Fix the bug in `ReactFlightServerConfigWebpackBundler.js`

A nullish coalescing operator was swapped.

The issue is in the `resolveClientReferenceMetadata` function.

Use the intended nullish/logical operator.