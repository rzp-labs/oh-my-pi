# Fix the bug in `ReactDOMContainer.js`

An equality operator is inverted.

The issue is on line 26.

Fix the equality comparison operator.