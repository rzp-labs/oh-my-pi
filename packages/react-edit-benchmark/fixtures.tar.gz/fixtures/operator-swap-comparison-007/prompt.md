# Fix the bug in `ReactFiberTreeReflection.js`

A comparison operator is subtly wrong.

Find and fix this issue.