# Fix the bug in `OpenInEditorButton.js`

A boolean literal is inverted.

The issue is on line 52.

Flip the boolean literal to the intended value.