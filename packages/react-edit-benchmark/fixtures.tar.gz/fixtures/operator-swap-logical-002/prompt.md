# Fix the bug in `ReactFlightThenable.js`

A boolean operator is incorrect.

The issue is in the `trackUsedThenable` function.

Use the intended boolean operator.