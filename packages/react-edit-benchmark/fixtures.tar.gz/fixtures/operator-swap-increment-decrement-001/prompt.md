# Fix the bug in `index.js`

An increment/decrement operator points the wrong direction.

The issue is on line 25.

Replace the increment/decrement operator with the intended one.