# Fix the bug in `parseSourceAndMetadata.js`

Two arguments in a call are swapped.

Find and fix this issue.