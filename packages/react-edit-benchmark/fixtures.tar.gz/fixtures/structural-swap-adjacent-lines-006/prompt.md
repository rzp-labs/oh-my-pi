# Fix the bug in `editor.js`

Two adjacent statements are in the wrong order.

The issue is near the top of the file.

Swap the two adjacent lines back to their original order.