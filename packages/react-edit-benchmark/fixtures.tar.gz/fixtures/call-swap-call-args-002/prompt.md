# Fix the bug in `ReactFlightClientConfigBundlerWebpack.js`

Two arguments in a call are swapped.

The issue is in the `resolveServerReference` function.

Swap the two arguments to their original order.