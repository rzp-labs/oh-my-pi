# Fix the bug in `ReactDOMInvalidARIAHook.js`

A string literal contains a lookalike unicode dash.

The issue is in the `validateProperties` function.

Replace the unicode dash with a plain ASCII hyphen.