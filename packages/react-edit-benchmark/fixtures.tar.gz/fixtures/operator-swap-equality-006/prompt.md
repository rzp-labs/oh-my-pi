# Fix the bug in `ReactFiberComponentStack.js`

An equality operator is inverted.

The issue is in the `getOwnerStackByFiberInDev` function.

Fix the equality comparison operator.