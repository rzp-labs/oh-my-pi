# Fix the bug in `ReactFlightDOMServerBrowser.js`

An arithmetic operator was swapped.

Find and fix this issue.