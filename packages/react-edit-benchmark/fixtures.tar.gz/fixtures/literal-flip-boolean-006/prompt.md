# Fix the bug in `InspectedElementSourcePanel.js`

A boolean literal is inverted.

The issue is in the `InspectedElementSourcePanel` function.

Flip the boolean literal to the intended value.