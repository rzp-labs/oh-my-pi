# Fix the bug in `ReactFlightDOMServerBrowser.js`

An equality operator is inverted.

Find and fix this issue.