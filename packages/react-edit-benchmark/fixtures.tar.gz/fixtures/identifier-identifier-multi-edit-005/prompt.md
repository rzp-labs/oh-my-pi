# Fix the bug in `githubAPI.js`

An identifier is misspelled in multiple separate locations.

The issue is on line 19.

Restore the identifier to its original spelling in all affected locations.