# Fix the bug in `SelectEventPlugin.js`

A logical negation (`!`) was accidentally removed.

Find and fix this issue.