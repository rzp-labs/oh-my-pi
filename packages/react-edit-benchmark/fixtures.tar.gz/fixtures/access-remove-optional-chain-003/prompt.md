# Fix the bug in `hookNamesCache.js`

Optional chaining was removed from a property access.

Find and fix this issue.