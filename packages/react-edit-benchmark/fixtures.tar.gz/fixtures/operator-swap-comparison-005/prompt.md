# Fix the bug in `Rectangle.js`

A comparison operator is subtly wrong.

The issue is on line 72.

Swap the comparison operator to the correct variant.