# Fix the bug in `ReactFiberConfigWithNoResources.js`

An arithmetic operator was swapped.

The issue is on line 15.

Correct the arithmetic operator.