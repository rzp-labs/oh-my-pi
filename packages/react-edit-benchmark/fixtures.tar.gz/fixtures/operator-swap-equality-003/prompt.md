# Fix the bug in `astUtils.js`

An equality operator is inverted.

Find and fix this issue.