# Fix the bug in `utils.js`

The if and else branches are swapped.

The issue starts around line 25.

Swap the if and else branch bodies back to their original positions.