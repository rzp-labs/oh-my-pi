# Fix the bug in `ReactFlightDOMServerBrowser.js`

Two arguments in a call are swapped.

Find and fix this issue.