# Fix the bug in `ReactDOMContainer.js`

A logical negation (`!`) was accidentally removed.

The issue is on line 20.

Add back the missing logical negation (`!`).