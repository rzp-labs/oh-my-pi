# Fix the bug in `ReactDOMSelection.js`

A logical negation (`!`) was accidentally removed.

Find and fix this issue.