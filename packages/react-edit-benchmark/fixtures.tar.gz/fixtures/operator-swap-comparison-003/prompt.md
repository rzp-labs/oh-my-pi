# Fix the bug in `ReactFlightDOMServerBrowser.js`

A comparison operator is subtly wrong.

Find and fix this issue.